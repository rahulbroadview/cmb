<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'coffeemeetsbagel-latest');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '37tzq9b9=8`.bSt4LG>ZG`*4]gnIj94UirnUyLA(!V3ZBK}cJ357zw,kA~r1ivFH');
define('SECURE_AUTH_KEY',  'Ho`d| {,*O:^p`J`x/HDA(19h`z4c?G<~DjAu(LM5yP}f)0z9&+{=ubn&dvU}5rq');
define('LOGGED_IN_KEY',    '69++Fw?y0Tb@T,BqF&kA1qJ?><)i0ttUjnZ(Wz$O5r1.K`ydAg6{`.mJ ^>3O*.z');
define('NONCE_KEY',        'W4^66;^Y3+yZmAtk::&}#lAK$BQRJF^Nj}vF&T#..dJv> 2Q#u072.wP+M-,AFRH');
define('AUTH_SALT',        '{z40%>}Gf0B8HEd>jYq^x+s,pu{ij|U2sU*!MSv`bNNg8fzC?`pV(T|//.hPoPl3');
define('SECURE_AUTH_SALT', '-dpn#PAvI{l]-vc4 ngq^Mk$k=9N|j-h[+#d:qX{k,&biBS7^~OvEZsXK1/}8xpw');
define('LOGGED_IN_SALT',   '07Z>5]hC^WWB&7?h=3rfzFPs`iY,]bfDh`SyhX6!=y)Ill^Ae><U2Qy_DHCo.K2!');
define('NONCE_SALT',       '6KT5h,A|/3ERu8c%V)z=>MOJpQxsshcl5C?IoRt=}AQWK[yQ=sj nkxwmMK9=fH1');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
